<?php
if (!defined("HDPHP_PATH"))exit('No direct script access allowed');
//事件定义
return array(
);
?>