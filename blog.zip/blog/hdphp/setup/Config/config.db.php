<?php 
if (!defined('HDPHP_PATH'))exit;
return array (
  'RBAC_DB_SET' => 1,
  'db_host' => '127.0.0.1',
  'db_port' => '3306',
  'db_user' => 'root',
  'db_password' => 'admin888',
  'db_database' => 'test',
  'db_prefix' => 'hd_',
) 
?>