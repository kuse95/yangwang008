<?php
//SETUP入口
define("DEBUG", TRUE);
define("APP_NAME", 'Setup');
define("APP_PATH", "./");
include "../hdphp/hdphp.php";
?>