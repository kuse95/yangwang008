<?php
header("Content-Type: text/html; charset=utf-8");
//定义项目名称
define('APP_NAME', 'Admin');
//定义项目路径
define('APP_PATH', './Admin/');
//定义调试模式开启
define('DEBUG',true);
//载入框架的核心文件
require './hdphp/hdphp/hdphp.php';